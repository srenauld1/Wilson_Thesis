% batteryStimG4PanelsFictrac_CLgain.m
%
% Trial Type Function for battery and stimulating
% Display pattern/function on G4 panels
% Record G4 panels and FicTrac channels
% Deliver light
% Closed-loop
% change gain of steering
%
% INPUTS:
%   settings - struct of ephys setup settings, from ephysSettings()
%   duration - min
%   pattN - select pattern
%   gainSet - used to set panel gain
%   stim - 1 for opto output, 0 for no opto output
%
% OUTPUTS:
%   rawData - raw data measured by DAQ, matrix where each column is data
%       from a different channel
%   inputParams - parameters for this experiment type
%   rawOutput - raw output sent by DAQ, matrix where each column is
%       different channel
%
% Adapted: 06/06/2024 - MC converted from menotaxis expt
%

function [rawData, inputParams, rawOutput] = batteryStimG4PanelsFictrac_CLgain(settings,duration,pattN,gainSet,stim)
%% SET VARIABLES
if stim
    % set voltage output for LED
    voltageOut = 0.125;
else
    voltageOut = 0;
end

%% INITIALIZE DAQ
inputParams.exptCond = 'StimG4PanelsFictrac_jumps'; % name of trial type

% which input and output data streams used in this experiment
inputParams.aInCh = {'ficTracHeading', 'ficTracIntX', 'ficTracIntY', 'g4panelXPosition','pythonJumpTrig'};
inputParams.aOutCh = {'optoExtCmd'};
inputParams.dInCh = {};
inputParams.dOutCh = {};

% initialize DAQ, including channels
[userDAQ, ~, ~, ~, ~] = initUserDAQ(settings, inputParams.aInCh, inputParams.aOutCh,...
    inputParams.dInCh, inputParams.dOutCh);

% generate output matrix for opto stimulation
rawOutput = ones(duration*settings.bob.sampRate,1)*voltageOut; %generate stim array

% queue opto stimulation output
userDAQ.queueOutputData(rawOutput);

%% SET PANEL PARAMETERS

disp('Initializing G4 panels...');
% panel settings
%mode = 4; %closed loop - frame rate
mode = 7; %closed loop - frame index

% pull settings and connect
userSettings %load settings
Panel_com('change_root_directory', exp_path);
load([exp_path '\currentExp'])
expt_t = duration;

%store pattern parameters
load(['patt_lookup_' sprintf('%04d', pattN)])
inputParams.pattern_name = patlookup.name;
inputParams.objectSize = patlookup.size;
inputParams.objectGS = patlookup.objgs;
inputParams.backgroundGS = patlookup.bckgs;
inputParams.panel_gain = gainSet;

% load panel parameters
Panel_com('set_control_mode', mode);
Panel_com('set_gain_bias', [100 0]);
Panel_com('set_pattern_id', pattN);

%% RESET FICTRAC
startFicTrac_gain(gainSet)
pause(1)

%% ACQUIRE
disp(['[' datestr(now,'HH:MM') '] Beginning: ' patlookup.name ' w/ ' 'closed-loop at ' num2str(gainSet) 'X gain'])
inputParams.trialDuration = expt_t;

% start experiment
pause(0.1) %slight delay
inputParams.startTimeStamp = datestr(now, 'HH:MM:SS');
Panel_com('start_display', expt_t); %sec
rawData = userDAQ.startForeground(); % acquire data (in foreground)
% stop experiment
pause(0.1)
userDAQ.outputSingleScan(0);
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows

disp('Finished trial.');
end