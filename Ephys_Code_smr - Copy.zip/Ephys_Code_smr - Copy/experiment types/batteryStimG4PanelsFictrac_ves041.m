% batteryStimG4PanelsFictrac_ves041.m
%
% Trial Type Function for battery and stimulating
% Display pattern/function on G4 panels
% Record G4 panels and FicTrac channels
% Deliver light
% Closed-loop
% change gain of steering
%
% INPUTS:
%   settings - struct of ephys setup settings, from ephysSettings()
%   duration - min
%   pattN - select pattern
%   gainSet - used to set panel gain
%   stim - 1 for opto output, 0 for no opto output
%
% OUTPUTS:
%   rawData - raw data measured by DAQ, matrix where each column is data
%       from a different channel
%   inputParams - parameters for this experiment type
%   rawOutput - raw output sent by DAQ, matrix where each column is
%       different channel
%
% Adapted: 06/06/2024 - MC converted from menotaxis expt
%

function [rawData, inputParams, rawOutput] = batteryStimG4PanelsFictrac_ves041(settings,duration,pattN,func,stim, cellDirPath)
%% SET VARIABLES
if stim == 1
    % set voltage output for LED
    voltageOut = 0.25;
    % generate output matrix for opto stimulation - 5s pulses
    % settings.bob.sampRate  = 20e3
    % if duration is 30, total points is 600,000
    % split into 6 5s blocks is 100000 each
    rawOutput_block = [zeros(1,100000), ones(1,100000), zeros(1,100000), ones(1,100000), zeros(1,100000), ones(1,100000)];
    rawOutput_trial = repmat(rawOutput_block, 1, (duration/300));
elseif stim == 2
    % set voltage output for LED
    voltageOut = 0.25;
    % settings.bob.sampRate  = 20e3
    % if duration is 15, total points is 300,000
    % this is a 15s block with 7 nothing, 1 sec of stim 7 nothing
    rawOutput_block = [zeros(1,140000), ones(1,20000), zeros(1,140000)];
    rawOutput_trial = repmat(rawOutput_block, 1, (duration/150));
elseif stim == 3
    % set voltage output for LED
    voltageOut = 0.5;
    % settings.bob.sampRate  = 20e3
    % if duration is 15, total points is 300,000
    % this is a 15s block with 7 nothing, 1 sec of stim 7 nothing
    rawOutput_block = [zeros(1,140000), ones(1,20000), zeros(1,140000)];
    rawOutput_trial = repmat(rawOutput_block, 1, (duration/150));
elseif stim == 4
    % set voltage output for LED
    voltageOut = 0.25;
    % settings.bob.sampRate  = 20e3
    % if duration is 15, total points is 300,000
    % if duration is 40, total is 800,000
    % this is a 40s block with 15 nothing, 10s stim, 15 nothing
    rawOutput_block = [zeros(1,300000), ones(1,200000), zeros(1,300000)];
    rawOutput_trial = repmat(rawOutput_block, 1, (duration/400));
elseif stim == 5
    % set voltage output for LED
    voltageOut = 0.25;
    % generate output matrix for opto stimulation - 5s pulses
    % settings.bob.sampRate  = 20e3
    % if duration is 30, total points is 600,000
    % this is a 30s block with 5s stim (12.5, 5, 12.5)
    rawOutput_block = [zeros(1, 250000), ones(1,100000), zeros(1, 250000)];
    rawOutput_trial = repmat(rawOutput_block, 1, (duration/300));
else
    voltageOut = 0;
end

%% INITIALIZE DAQ
inputParams.exptCond = 'StimG4PanelsFictrac'; % name of trial type

% which input and output data streams used in this experiment
inputParams.aInCh = {'ficTracHeading', 'ficTracIntX', 'ficTracIntY', 'g4panelXPosition','pythonJumpTrig'};
inputParams.aOutCh = {'optoExtCmd'};
inputParams.dInCh = {};
inputParams.dOutCh = {};

% initialize DAQ, including channels
[userDAQ, ~, ~, ~, ~] = initUserDAQ(settings, inputParams.aInCh, inputParams.aOutCh,...
    inputParams.dInCh, inputParams.dOutCh);

% scale raw output by voltage
rawOutput = (rawOutput_trial*voltageOut)'; %generate stim array

% queue opto stimulation output
release(userDAQ);
userDAQ.queueOutputData(rawOutput);

%% SET PANEL PARAMETERS

disp('Initializing G4 panels...');
% panel settings
%mode = 4; %closed loop - frame rate
if func == 1 % cl bar, no jumps
    mode = 7; %closed loop - frame index
    ftMode = 0; %closed loop - frame index
    % pull settings and connect
    userSettings %load settings
    Panel_com('change_root_directory', exp_path);
    load([exp_path '\currentExp'])
    expt_t = duration;
    
    %store pattern parameters
    load(['patt_lookup_' sprintf('%04d', pattN)])
    inputParams.pattern_name = patlookup.name;
    inputParams.objectSize = patlookup.size;
    inputParams.objectGS = patlookup.objgs;
    inputParams.backgroundGS = patlookup.bckgs;
    % SMR CHANGE
    inputParams.panel_gain = 70;
    
    % load panel parameters
    Panel_com('set_control_mode', mode);
    %Panel_com('set_gain_bias', [100 0]);
    Panel_com('set_pattern_id', pattN);
% need to determine what open loop looks like!!
% elseif func==0
%     % this no longer works (lost the py file for open loop)
%     mode = 0; %open loop
%     ftMode = 0; %open loop
%         % pull settings and connect
%     userSettings %load settings
%     Panel_com('change_root_directory', exp_path);
%     load([exp_path '\currentExp'])
%     expt_t = duration;
%     funcN = 146;
% 
%     %store pattern parameters
%     load(['patt_lookup_' sprintf('%04d', pattN)])
%     inputParams.pattern_name = patlookup.name;
%     inputParams.objectSize = patlookup.size;
%     inputParams.objectGS = patlookup.objgs;
%     inputParams.backgroundGS = patlookup.bckgs;
%     %store function parameters
%     load(['func_lookup_' sprintf('%04d', funcN)])
%     inputParams.function_name = funlookup.name;
%     inputParams.sweepRange = funlookup.sweepRange;
%     inputParams.sweepRate = funlookup.sweepRate;
%     inputParams.sweepDur = (funlookup.sweepRange/funlookup.sweepRate)*2;
% 
%     % load panel parameters
%     Panel_com('set_control_mode', mode);
%     Panel_com('set_pattern_id', pattN);
%     Panel_com('set_pattern_func_id', funcN);
elseif func == 2 % cl bar, bar jumps
    mode = 7; %closed loop - frame index
    ftMode = 1; %closed loop - frame index
    % pull settings and connect
    userSettings %load settings
    Panel_com('change_root_directory', exp_path);
    load([exp_path '\currentExp'])
    expt_t = duration;
    
    %store pattern parameters
    load(['patt_lookup_' sprintf('%04d', pattN)])
    inputParams.pattern_name = patlookup.name;
    inputParams.objectSize = patlookup.size;
    inputParams.objectGS = patlookup.objgs;
    inputParams.backgroundGS = patlookup.bckgs;
    % SMR CHANGE
    inputParams.panel_gain = 70;
    
    % load panel parameters
    Panel_com('set_control_mode', mode);
    %Panel_com('set_gain_bias', [100 0]);
    Panel_com('set_pattern_id', pattN);
end


%% RESET FICTRAC
startFicTrac_smr(cellDirPath, ftMode)
pause(1)

%% ACQUIRE
% SMR change naming
disp(['[' datestr(now,'HH:MM') '] Beginning: ' patlookup.name ' w/ ' 'closed/open-loop ' num2str(func)])
expt_t = duration/10;
inputParams.trialDuration = expt_t;
%release(userDAQ);
% start experiment
pause(0.1) %slight delay
inputParams.startTimeStamp = datestr(now, 'HH:MM:SS');
Panel_com('start_display', expt_t); %sec
rawData = userDAQ.startForeground(); % acquire data (in foreground)
% stop experiment
pause(0.1)
userDAQ.outputSingleScan(0);
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows

disp('Finished trial.');
end