% startFicTrac
%
% function for starting fictrac configuration based on input
% specifications, specifically changes the gain of the yaw to panel
% position transformation
%
% INPUTS
% gainSelect  - yaw gain
%
% Created: 07/17/2024 MC created from _noise

function startFicTrac_gain(gainSelect)
%% configure fictrac
% set config file to be used
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows
thisConfig = 'config.txt';
pause(0.5)


%% start fictrac
% socket_client_360_cl_mode7.py
% launch fictrac gui
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows
disp('Launching fictrac...');
fictracStart = ['cd/ & cd /d C:\src\fictrac & fictrac.exe ' thisConfig ' &'];
[~,~] = system(fictracStart);
pause(0.5)
%select python script to run
disp(['Gain set: ' num2str(gainSelect)]);
thisSocketClient = ['socket_client_360_cl_fixate_jumps_' num2str(gainSelect)];
% start python script
disp(['Launching ' thisSocketClient '...']);
pythonStart = ['cd/ & cd /d C:\src\fictrac & python ' thisSocketClient '.py &'];
[~,~] = system(pythonStart);

disp('Fictrac ready.');


end

