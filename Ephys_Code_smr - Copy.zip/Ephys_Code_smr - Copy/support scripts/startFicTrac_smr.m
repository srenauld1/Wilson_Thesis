% startFicTrac
%
% function for starting fictrac configuration, if not already configured,
% and launching fictrac/python, if not already running
%
% INPUTS
% cellDirPath - load in cell path to export config image - SMR rm
% ftMode -  0 set to open-loop
%           1 set to closed-loop via frame rate
%           2 set to closed-loop via frame index
%           3 set to clsoed-loop via frame index WITH bar jumps
%           5 set to leg camera
%
% Created: 11/05/2021 MC
% Updated: 04/20/2022 MC added open/closed loop alternatives
% Updated: 10/30/2023 MC added leg camera option

function startFicTrac_smr(cellDirPath, ftMode)
%% configure fictrac
% Set config file to be used
if ftMode == 5
    thisConfig = 'config_leg.txt';
else
    system('Taskkill /IM cmd.exe'); % Terminate any previous FicTrac windows
    thisConfig = 'config_live.txt';
    pause(1)
end

% Check if cellDirPath is provided
if ~isempty(cellDirPath) && ~ischar(cellDirPath)
    error('cellDirPath must be a string or empty (None).');
end

if ~isempty(cellDirPath) % Only configure FicTrac if cellDirPath is provided
    % Only if it has not yet been configured for this experiment,
    % as indicated by a moved configImg in the experiment directory
    if ~exist([cellDirPath '\fictrac-configImg.png'], 'file')
        % Start FicTrac config
        fictracCfg = ['cd/ & cd /d C:\src\fictrac & configGui.exe ' thisConfig ' &'];
        [~, ~] = system(fictracCfg);
        check = input('[INPUT] Configure FicTrac...');

        % Move FicTrac config image to data directory
        copyfile('C:\src\fictrac\fictrac-configImg.png', cellDirPath, 'f');
    else
        disp('FicTrac previously configured.');
    end
else
    disp('cellDirPath is None. Skipping FicTrac configuration.');
end

%% start FicTrac
% Launch FicTrac GUI
system('Taskkill /IM cmd.exe'); % Terminate any previous FicTrac windows
disp('Launching FicTrac...');
fictracStart = ['cd/ & cd /d C:\src\fictrac & fictrac.exe ' thisConfig ' &'];
[~, ~] = system(fictracStart);

% Select Python script to run
subDir = 'smr'; % Define the subdirectory where Python scripts are located

switch ftMode
    case 0
        disp('MODE SELECTION: closed-loop');
        thisSocketClient = 'socket_client_360_smr_cl08_2pi'; % Closed-loop, no bar jump
    case 1
        disp('MODE SELECTION: closed-loop WITH bar jumps');
        thisSocketClient = 'socket_client_360_smr_jump_2pi'; % Closed-loop, bar jump
    otherwise
        error('Invalid ftMode selected.');
end

% Launch the Python script if selected
if ~isempty(thisSocketClient)
    pythonStart = sprintf('cd/ & cd /d C:\\src\\fictrac\\%s & python %s.py &', subDir, thisSocketClient);
    disp(['Launching ' thisSocketClient ' from subdirectory ' subDir '...']);
    [~, ~] = system(pythonStart);
else
    disp('No Python script launched.');
end

disp('FicTrac ready.');
end
