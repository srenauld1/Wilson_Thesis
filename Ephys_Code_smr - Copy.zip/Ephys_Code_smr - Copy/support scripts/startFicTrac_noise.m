% startFicTrac
%
% function for starting fictrac configuration, if not already configured,
% and launching fictrac/python, if not already running
%
% INPUTS
% cellDirPath - load in cell path to export config image
% noiseLvl    - level of noise to be injected into closed-loop trajectory
%
% Created: 11/05/2021 MC
% Updated: 06/06/2024 MC created from startFicTrac

function startFicTrac_noise(noiseLvl)
%% configure fictrac
% set config file to be used
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows
thisConfig = 'config.txt';
pause(1)


%% start fictrac

% launch fictrac gui
system('Taskkill/IM cmd.exe'); %terminate any previous fictrac windows
disp('Launching fictrac...');
fictracStart = ['cd/ & cd /d C:\src\fictrac & fictrac.exe ' thisConfig ' &'];
[~,~] = system(fictracStart);

%select python script to run
disp(['Noise lvl ' num2str(noiseLvl)]);
thisSocketClient = ['socket_client_360_cl_mode7_noise_' num2str(noiseLvl)];
% start python script
disp(['Launching ' thisSocketClient '...']);
pythonStart = ['cd/ & cd /d C:\src\fictrac & python ' thisSocketClient '.py &'];
[~,~] = system(pythonStart);

disp('Fictrac ready.');


end

