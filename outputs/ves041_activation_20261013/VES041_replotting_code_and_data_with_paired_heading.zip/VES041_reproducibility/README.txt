VES041 csChrimson activation: reproducible analysis and plots
13 October 2026

This package reproduces the quantitative plots in the presentation from
local exported data. It does not require the Neurobio server.

Run
  python3 analyze_ves041.py
  Rscript replot_ves041.R

Python requires numpy and pandas. R requires ggplot2, dplyr, tidyr,
jsonlite, patchwork, svglite and ragg. Arial was used for figure text.
R_session_info.txt records the plotting environment used for this deck.

On the original machine the Python executable used was:
/Users/sophiarenauld/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
R was /usr/local/bin/Rscript (R 4.4.1).

Files
  source_data/ holds exact copies of the local numeric source exports and
  relevant upstream scripts. presentation_metrics.csv and other source
  exports also contain SMP544 records. The script explicitly selects only
  dataset == ves041_activation. It never adds those records to VES041.

  derived/ holds fly-level estimates, per-pulse-bin aggregates, exploratory
  comparison statistics, threshold sensitivity and deck_data.json.

  figures/ holds 13 scientific figures in PNG and vector SVG formats.
  Open the SVG files in a vector editor, or edit the R code to replot.

  heading_pre_post shows exactly two dots per fly, connected within each
  genotype. Pre is the 1 s before light onset. Post is the first 1 s after
  onset, while light is on, not the period after light offset. Each dot is
  the mean absolute net heading change across 80 pulses for that fly.
  The heading change is the absolute unwrapped endpoint difference within
  each window, not cumulative turning or an absolute compass orientation.
  derived/heading_pairs81.csv contains the 81 paired records, and
  heading_pairs_long81.csv contains the 162 plotted points. The descriptive
  group means and existing fly-bootstrap change intervals are in
  heading_paired_summary81.csv. No new hypothesis-test family is added.

  source_registry.json records original locations and original-file hashes.
  deck_data.json also records the input snapshot hashes, methods and seed.

Data conventions
  The archived summary has 84 unique flies. The pulse-derived dataset has
  81 unique flies, each with 80 stimuli (6,480 events). These are overlapping
  datasets, not independent replications. Missing pulse-analysis IDs are
  1, 6 and 39. IDs 1 and 6 are absent from the archived extraction lists.
  ID 39 appears in the recording manifest but has no extracted metrics.
  The specific extraction failure for ID 39 is not independently verified.

  The main event analysis compares the first second of light with the
  preceding second. Each fly has equal weight. No synthetic observations,
  imputation or outlier removal are used. Horizontal point jitter only
  improves visibility; vertical numeric values do not change.

  Rotational speed in the pulse export uses smoothedangularVelocity. The
  archived summary pipeline uses raw velocity fields and contains a
  moving-only summary path. The 84-fly CSV does not retain per-pulse
  inclusion metadata, so it is shown separately from all-pulse estimates.

  The baseline-state sensitivity uses pre-stimulation mean forward speed
  >= 3 mm/s, matching minVel=3 in master_behavior_analysis.m. It retains
  2,140 pulses and all 81 flies. This is descriptive and can be affected by
  conditioning on baseline. Control groups remain necessary.

  The legacy acceleration columns are preserved in their original source
  units. Their physical scaling is unresolved, so they are not used for
  the biological interpretation.

Statistics
  Seed: 20261013. Bootstrap: 20,000 resamples of flies. Intervals are
  pointwise 95% percentile intervals, not simultaneous confidence bands.

  Twelve new exploratory contrasts compare the change in each activation
  line with its matched GFP and empty-split controls for forward velocity,
  rotational speed and absolute net heading. Each comparison uses 100,000
  random-label permutations and a plus-one p-value correction. BH FDR is
  applied across all 12 comparisons. These tests are retrospective, not
  preregistered. Exact results are in exploratory_tests81.csv.

  The pooled pivot p-value on slide 13 comes from the previously saved
  ves041_activation_tests.csv. It belongs to that analysis's six-metric
  correction family, separately from the twelve new contrasts. The new
  code reproduces the underlying pivot rates and all nine saved threshold
  sensitivity values from the event table.

  Strict pivot rule: absolute net heading >=45 deg, net displacement <=2mm,
  directionality >=0.7. Directionality is absolute net heading / cumulative
  absolute heading change. The same rule applies before and during light.

Presentation assets
  Original example path figures come from labmeeting_9.pptx slide 22.
  image32 is the source-labeled VES041 example and image31 the empty-split
  control. Their arbitrary-unit axes are retained. These examples are
  illustrative and do not establish the 2mm pivot cutoff.

  The fly-on-ball schematic comes from slide 18 of that deck. Only
  surrounding transparent whitespace is cropped within the slide layout.

  PowerPoint text, tables and the pivot overview chart remain editable.
  Detailed scientific plots are embedded figures with these SVG/code
  counterparts. Pivot-chart workbook values are rounded to eight decimal
  places for Excel compatibility. Unrounded estimates remain in the CSVs.

Scope
  This reproduction begins with saved local numeric exports. It does not
  rerun raw acquisition processing, reconstruct unseen raw traces, infer
  response onset latency, or establish a downstream circuit mechanism.
  Earlier pilot and inhibition data are not pooled into this cohort.
