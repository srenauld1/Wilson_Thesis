"""Reproduce VES041 slides from local exported data; no server is used.

Requires Python 3, numpy and pandas. Run beside source_data/.
No observations are invented, imputed, rescaled or removed as outliers.
The original 84-fly table and the 81-fly pulse dataset are kept separate.
"""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'source_data'
OUT = ROOT / 'derived'
OUT.mkdir(exist_ok=True)
SEED = 20261013
BOOT = 20000
PERM = 100000
rng = np.random.default_rng(SEED)
ORDER = ['ves041_1_Chrim','ves041_2_Chrim','ves041_1_gfp','ves041_2_gfp','empty_Chrim']
LABELS = ['Line 1 + csChrimson','Line 2 + csChrimson','Line 1 + GFP','Line 2 + GFP','Empty + csChrimson']
COLORS = ['#B85F35','#167D8D','#8F9AA8','#596A7F','#B6A88A']
mapping_text = (SRC/'cschrim_behaviorcrunch.R').read_text()
mapping = {int(n): g for ids,g in re.findall(r'Fly %in% c\(([^)]+)\) ~ "([^"]+)"',mapping_text) for n in re.findall(r'\d+',ids)}
assert len(mapping)==84

def bootstrap_mean(x):
    x=np.asarray(x,dtype=float)
    assert np.isfinite(x).all()
    means=x[rng.integers(0,len(x),(BOOT,len(x)))].mean(axis=1)
    return float(x.mean()), *np.quantile(means,[.025,.975]).tolist()

def contrast(a,b):
    a=np.asarray(a);b=np.asarray(b);obs=float(a.mean()-b.mean())
    bs=a[rng.integers(0,len(a),(BOOT,len(a)))].mean(axis=1)-b[rng.integers(0,len(b),(BOOT,len(b)))].mean(axis=1)
    pool=np.r_[a,b]; hits=0
    for _ in range(PERM//1000):
        # Random continuous ranks give uniformly sampled label permutations.
        ix=rng.random((1000,len(pool))).argsort(axis=1)
        shuffled=pool[ix]
        d=shuffled[:,:len(a)].mean(axis=1)-shuffled[:,len(a):].mean(axis=1)
        hits+=np.count_nonzero(np.abs(d)>=abs(obs)-1e-12)
    return obs,*np.quantile(bs,[.025,.975]).tolist(),float((hits+1)/(PERM+1))

def bh(p):
    p=np.array(p);idx=np.argsort(p);q=np.minimum.accumulate((p[idx]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    result=np.empty(len(p));result[idx]=np.minimum(q,1);return result

summary=pd.read_csv(SRC/'fly_summary_84.csv')
summary.columns=summary.columns.str.strip()
summary=summary.loc[pd.to_numeric(summary.Fly,errors='coerce').notna()].copy()
summary['Fly']=summary.Fly.astype(int)
summary['genotype']=summary.Fly.map(mapping)
assert len(summary)==84 and summary.Fly.is_unique and summary.genotype.notna().all()
summary['delta_fwd']=summary['Opto On Forward Velocity']-summary['Pre Opto Forward Velocity']
summary['delta_rot']=summary['Opto On Rotational Speed']-summary['Pre Opto Rotational Speed']
summary['heading']=summary['Net Heading Displacement (deg)']
summary['delta_fwd_accel']=summary['Opto On Forward Acceleration']-summary['Pre Opto Forward Acceleration']
summary['delta_rot_accel']=summary['Opto On Rotational Acceleration']-summary['Pre Opto Rotational Acceleration']
summary.to_csv(OUT/'summary84.csv',index=False)

events=pd.read_csv(SRC/'presentation_metrics.csv')
events=events.loc[events.dataset.eq('ves041_activation')].copy()
events['Fly']=events.fly.str.extract(r'fly(\d+)$').astype(int)
events['genotype']=events.Fly.map(mapping)
assert len(events)==6480 and events.Fly.nunique()==81
assert not events.duplicated(['fly','recording','pulse']).any()
assert events.groupby('fly').size().eq(80).all()
assert events.genotype.notna().all()
assert set(events.Fly)==set(summary.Fly)-{1,6,39}
assert (events['group'].eq('experimental')==events.genotype.isin(ORDER[:2])).all()

for window in ['pre_1s','opto_1s']:
    events['pivot_'+window]=((events['abs_net_heading_deg_'+window]>=45)&
        (events['displacement_'+window]<=2)&(events['turn_directionality_'+window]>=.7)).astype(float)
METRICS={
 'fwd':('mean_forward_velocity','Forward velocity (mm/s)'),
 'rot':('mean_abs_angular_velocity','Rotational speed (deg/s)'),
 'heading':('abs_net_heading_deg','Absolute net heading (deg)'),
 'pivot':('pivot','Pivot-like events (%)')}
cols=[f'{field}_{window}' for field,_ in METRICS.values() for window in ['pre_1s','opto_1s']]
fly=events.groupby(['Fly','genotype','group'])[cols].mean().reset_index()
for metric,(field,_) in METRICS.items():
    scale=100 if metric=='pivot' else 1
    fly[metric+'_pre']=fly[field+'_pre_1s']*scale
    fly[metric+'_opto']=fly[field+'_opto_1s']*scale
    fly['delta_'+metric]=fly[metric+'_opto']-fly[metric+'_pre']
fly.to_csv(OUT/'fly81.csv',index=False)
saved=pd.read_csv(SRC/'fly_level_summary.csv')
saved=saved.loc[saved.dataset.eq('ves041_activation')].copy()
saved['Fly']=saved.fly.str.extract(r'fly(\d+)$').astype(int)
j=fly.merge(saved,on='Fly',validate='one_to_one')
assert np.allclose(j.delta_pivot/100,j.delta_pivot_rate)
assert np.allclose(j.delta_heading,j.mean_delta_abs_net_heading)

rows=[]
for metric in METRICS:
    for g in ORDER:
        d=fly.loc[fly.genotype.eq(g)]
        for condition in ['pre','opto','delta']:
            c=condition+'_'+metric if condition=='delta' else metric+'_'+condition
            mean,lo,hi=bootstrap_mean(d[c])
            rows.append(dict(metric=metric,genotype=g,condition=condition,n=len(d),mean=mean,lo=lo,hi=hi))
means=pd.DataFrame(rows);means.to_csv(OUT/'group_estimates81.csv',index=False)

comparisons=[(ORDER[0],ORDER[2],'Line 1 vs GFP'),(ORDER[0],ORDER[4],'Line 1 vs empty'),
             (ORDER[1],ORDER[3],'Line 2 vs GFP'),(ORDER[1],ORDER[4],'Line 2 vs empty')]
tests=[]
for metric in ['fwd','rot','heading']:
    for a,b,label in comparisons:
        est,lo,hi,p=contrast(fly.loc[fly.genotype.eq(a),'delta_'+metric],fly.loc[fly.genotype.eq(b),'delta_'+metric])
        tests.append(dict(metric=metric,experimental=a,control=b,comparison=label,estimate=est,lo=lo,hi=hi,p=p))
tests=pd.DataFrame(tests);tests['q']=bh(tests.p);tests.to_csv(OUT/'exploratory_tests81.csv',index=False)

threshold=[]
for turn in [30,45,60]:
    for disp in [1,2,3]:
        flags={w:((events['abs_net_heading_deg_'+w]>=turn)&(events['displacement_'+w]<=disp)&(events['turn_directionality_'+w]>=.7)).astype(float) for w in ['pre_1s','opto_1s']}
        tmp=events[['Fly','group']].copy();tmp['delta']=(flags['opto_1s']-flags['pre_1s'])*100
        gm=tmp.groupby(['Fly','group']).delta.mean().reset_index().groupby('group').delta.mean()
        threshold.append(dict(turn=turn,displacement=disp,estimate=gm.experimental-gm.control))
threshold=pd.DataFrame(threshold);threshold.to_csv(OUT/'threshold_sensitivity.csv',index=False)

# Pulse-order trajectories use 8 consecutive bins of 10 pulses, equal fly weight.
events['pulse_bin']=((events.pulse-1)//10+1).astype(int)
binned=events.groupby(['Fly','genotype','group','pulse_bin'])[['delta_abs_net_heading_deg_1s','delta_mean_forward_velocity_1s']].mean().reset_index()
binned.to_csv(OUT/'pulse_bins_by_fly.csv',index=False)
trends=[]
for (g,b),d in binned.groupby(['genotype','pulse_bin']):
    for metric,c in [('heading','delta_abs_net_heading_deg_1s'),('fwd','delta_mean_forward_velocity_1s')]:
        mean,lo,hi=bootstrap_mean(d[c]);trends.append(dict(genotype=g,bin=int(b),metric=metric,mean=mean,lo=lo,hi=hi))
pd.DataFrame(trends).to_csv(OUT/'pulse_trends.csv',index=False)

# Descriptive baseline-state sensitivity. The 3 mm/s cutoff comes from
# master_behavior_analysis.m (minVel=3), not a search for significance.
state=[]
for label,mask in [('All pulses',np.ones(len(events),dtype=bool)),('Pre speed >= 3 mm/s',events.mean_forward_velocity_pre_1s>=3)]:
    selected=events.loc[mask]
    a=selected.groupby(['Fly','genotype']).agg(delta_fwd=('delta_mean_forward_velocity_1s','mean'),pulses=('pulse','size')).reset_index()
    a['selection']=label;state.append(a)
state=pd.concat(state,ignore_index=True)
state.to_csv(OUT/'baseline_state_fly.csv',index=False)
state_est=[]
for (g,s),d in state.groupby(['genotype','selection']):
    mean,lo,hi=bootstrap_mean(d.delta_fwd)
    state_est.append(dict(genotype=g,selection=s,n_flies=len(d),n_pulses=int(d.pulses.sum()),mean=mean,lo=lo,hi=hi))
pd.DataFrame(state_est).to_csv(OUT/'baseline_state_estimates.csv',index=False)

# Every fly's joint change is shown; no pulse is treated as an independent fly.
legacy=[]
for g in ORDER:
    d=summary.loc[summary.genotype.eq(g)]
    row=dict(genotype=g,n=len(d))
    for c in ['delta_fwd','delta_rot','heading','delta_fwd_accel','delta_rot_accel']:
        row[c]=float(d[c].mean())
    legacy.append(row)
pd.DataFrame(legacy).to_csv(OUT/'legacy_group_means.csv',index=False)

manifest={p.name:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in SRC.iterdir() if p.is_file()}
meta=dict(seed=SEED,bootstrap_replicates=BOOT,permutations=PERM,group_order=ORDER,labels=LABELS,colors=COLORS,
 summary_n=84,event_n=81,pulses=6480,missing_from_event=[1,6,39],source_files=manifest,
 missing_explanation={'1':'Not included in archived extraction ID lists.','6':'Not included in archived extraction ID lists.','39':'In recording manifest but no extracted pulse metrics; source extractor skips legacy non-HDF5 MAT files. Specific cause not independently verified.'},
 methods='Mean of 80 pulses per fly. During = first 1 s of stimulation, baseline = preceding 1 s. Delta = during - baseline. Equal fly weight. No imputation/outlier exclusion. CIs = percentile fly bootstrap, not simultaneous. Two-sided random-label permutation tests, 100000 shuffles with plus-one correction. BH FDR across 12 exploratory genotype contrasts (3 metrics x 4 comparisons).',
 caveats=['The 84-fly summary does not store pulse inclusion or filtering metadata. It is shown separately and is not pooled with 81-fly all-pulse metrics.',
 'Rotational speed in the event table uses the archived smoothedangularVelocity field, not the unsmoothed source velocity.',
 'Acceleration values in the legacy summary have ambiguous scaling and are shown only in original source units.',
 'This reproduction starts from local numeric exports; original raw acquisition and preprocessing are not rerun.'])
meta['pooled']=fly.groupby('group')[['pivot_pre','pivot_opto','delta_pivot','delta_heading','delta_fwd','delta_rot']].mean().to_dict('index')
meta['groups']=means.to_dict('records');meta['tests']=tests.to_dict('records');meta['legacy']=legacy
meta['baseline_state']=state_est
(OUT/'deck_data.json').write_text(json.dumps(meta,indent=2))
print(tests.round(6).to_string(index=False))
print('\nGROUP MEANS\n',fly.groupby('genotype')[[m+'_'+c for m in METRICS for c in ['pre','opto']]].mean().round(3).to_string())
print('\nPOOLED\n',json.dumps(meta['pooled'],indent=2))
print('\nValidated 84 summary flies, 81 event flies, 6480 pulses; archived heading/pivot summaries reproduced.')
