# Replot the VES041 analysis without a server connection.
# First run analyze_ves041.py. R packages: ggplot2, dplyr, tidyr,
# jsonlite, svglite, ragg, patchwork. All points are observed fly values.
suppressPackageStartupMessages({library(ggplot2);library(dplyr);library(tidyr);library(jsonlite);library(patchwork)})
args <- commandArgs(trailingOnly=FALSE)
script <- sub('^--file=', '', args[grepl('^--file=',args)][1])
root <- dirname(normalizePath(script))
setwd(root)
dir.create('figures',showWarnings=FALSE)
meta <- fromJSON('derived/deck_data.json')
ord <- meta$group_order
colors <- setNames(meta$colors,ord)
short <- setNames(c('L1 +\ncsChrimson','L2 +\ncsChrimson','L1 + GFP','L2 + GFP','Empty +\ncsChrimson'),ord)
long <- setNames(meta$labels,ord)
fly <- read.csv('derived/fly81.csv')
est <- read.csv('derived/group_estimates81.csv')
legacy <- read.csv('derived/summary84.csv',check.names=FALSE)
tests <- read.csv('derived/exploratory_tests81.csv')
theme_set(theme_classic(base_size=17,base_family='Arial') +
 theme(text=element_text(color='#182B3A'),axis.text=element_text(color='#34485A'),
       axis.line=element_line(color='#A7B1BA',linewidth=.35),axis.ticks=element_line(color='#A7B1BA',linewidth=.35),
       axis.title=element_text(size=17),axis.title.x=element_text(margin=margin(t=12)),
       axis.title.y=element_text(margin=margin(r=12)),
       panel.grid.major.y=element_line(color='#E8ECEF',linewidth=.3),
       plot.title=element_text(size=19,face='bold',margin=margin(b=12)),
       plot.subtitle=element_text(size=14,color='#586776',margin=margin(b=14)),
       legend.position='none',plot.margin=margin(12,18,10,12)))
savefig <- function(p,name,w=11.6,h=4.85){
 ggsave(paste0('figures/',name,'.png'),p,width=w,height=h,dpi=220,bg='white',device=ragg::agg_png)
 ggsave(paste0('figures/',name,'.svg'),p,width=w,height=h,bg='white',device=svglite::svglite)
}
factorize <- function(d){d$genotype <- factor(d$genotype,levels=ord);d}
fly <- factorize(fly);est <- factorize(est);legacy <- factorize(legacy)
counts <- table(fly$genotype)
axis_labels <- function(x)paste0(short[x],'\n(n = ',counts[x],')')
delta_plot <- function(metric,ylab){
 d <- fly;d$value <- d[[paste0('delta_',metric)]]
 e <- est[est$metric==metric & est$condition=='delta',]
 stopifnot(nrow(e)==5)
 ggplot(d,aes(genotype,value,color=genotype)) +
  geom_hline(yintercept=0,color='#687A88',linewidth=.5,linetype='dashed') +
  geom_point(position=position_jitter(width=.13,height=0,seed=20261013),size=2.5,alpha=.72) +
  geom_errorbar(data=e,aes(y=mean,ymin=lo,ymax=hi),width=.13,linewidth=.8,color='#182B3A') +
  geom_point(data=e,aes(y=mean),shape=23,fill='white',color='#182B3A',size=3.8,stroke=1) +
  scale_color_manual(values=colors)+scale_x_discrete(labels=axis_labels)+labs(x=NULL,y=ylab)
}
savefig(delta_plot('heading','Change in absolute\nnet heading (deg)'), 'heading_delta')
savefig(delta_plot('rot','Change in rotational\nspeed (deg/s)'), 'rotation_delta')
savefig(delta_plot('fwd','Change in forward\nvelocity (mm/s)'), 'forward_delta')

# Two dots per fly with the starting heading DEFINED as zero. Offsets on x
# separate flies but are identical at both endpoints and never alter angles.
hp <- read.csv('derived/heading_pairs_long81.csv')
hp <- factorize(hp)
hp$condition <- factor(hp$condition,levels=c('Before','After'))
stopifnot(nrow(hp)==162,length(unique(hp$Fly))==81,all(table(hp$Fly)==2))
stopifnot(all(hp$n_pulses==80),!anyNA(hp$signed_heading_deg),!anyNA(hp$absolute_heading_deg))
stopifnot(all(subset(hp,condition=='Before')$signed_heading_deg==0),
          all(subset(hp,condition=='Before')$absolute_heading_deg==0))
offsets <- hp %>% distinct(Fly,genotype) %>% arrange(genotype,Fly) %>%
 group_by(genotype) %>% mutate(x_offset=seq(-.28,.28,length.out=n())) %>% ungroup()
hp <- left_join(hp,offsets,by=c('Fly','genotype'))
hp$x <- as.integer(hp$condition)+hp$x_offset
paired_labels <- setNames(paste0(short[ord],'\n(n = ',counts[ord],')'),ord)
relative_heading_plot <- function(column,ylab,limits,breaks){
 d <- hp;d$value <- d[[column]]
 stopifnot(all(d$value>=limits[1]),all(d$value<=limits[2]))
 ggplot(d,aes(x,value,group=Fly,color=genotype))+
  geom_hline(yintercept=0,color='#8997A2',linewidth=.4,linetype='dashed')+
  geom_line(alpha=.45,linewidth=.48)+
  geom_point(data=subset(d,condition=='Before'),shape=21,fill='white',size=1.75,stroke=.65,alpha=.95)+
  geom_point(data=subset(d,condition=='After'),aes(fill=genotype),shape=21,size=2.25,stroke=.65,alpha=.95)+
  facet_wrap(~genotype,nrow=1,labeller=as_labeller(paired_labels))+
  scale_color_manual(values=colors)+scale_fill_manual(values=colors)+
  scale_x_continuous(limits=c(.50,2.50),breaks=c(1,2),labels=c('Before','After'),expand=expansion(mult=0))+
  scale_y_continuous(limits=limits,breaks=breaks,expand=expansion(mult=c(.035,.035)))+
  labs(x=NULL,y=ylab)+
  theme(strip.background=element_blank(),strip.text=element_text(size=14,face='bold',margin=margin(b=14)),
        axis.text.x=element_text(size=15),panel.spacing=grid::unit(1.05,'lines'))
}
savefig(relative_heading_plot('signed_heading_deg','Heading relative to onset (deg)',
    c(-60,60),seq(-60,60,30)),'heading_relative_signed')
savefig(relative_heading_plot('absolute_heading_deg','Absolute heading shift\nfrom onset (deg)',
    c(0,120),seq(0,120,30)),'heading_relative_absolute')

# Exact archived summaries, displayed separately from pulse-derived results.
legacy_delta <- function(metric,ylab){
 d=legacy;d$value=d[[metric]]
 e=d %>% group_by(genotype) %>% summarise(mean=mean(value),.groups='drop')
 ggplot(d,aes(genotype,value,color=genotype))+
  geom_hline(yintercept=0,linetype='dashed',color='#687A88',linewidth=.4)+
  geom_point(position=position_jitter(width=.13,height=0,seed=20261013),alpha=.75,size=2.5)+
  geom_point(data=e,aes(y=mean),shape=23,size=3.8,fill='white',color='#182B3A',stroke=1)+
  scale_color_manual(values=colors)+scale_x_discrete(labels=function(x)setNames(c('L1\ncsChrim','L2\ncsChrim','L1\nGFP','L2\nGFP','Empty\ncsChrim'),ord)[x])+
  labs(x=NULL,y=ylab)+theme(axis.text.x=element_text(size=12),axis.title.y=element_text(size=15))
}
savefig(legacy_delta('delta_fwd','Forward-velocity change (mm/s)')+
        legacy_delta('delta_rot','Rotational-speed change (deg/s)'), 'legacy_summary',11.6,4.85)
savefig(legacy_delta('heading','Archived heading displacement (deg)'), 'legacy_heading')
savefig(legacy_delta('delta_fwd_accel','Forward-acceleration change\n(original source units)')+
        legacy_delta('delta_rot_accel','Rotational-acceleration change\n(original source units)'), 'legacy_acceleration',11.6,4.85)

# Exploratory differences in within-fly changes. Intervals are pointwise,
# 95% percentile bootstrap CIs, not simultaneous intervals.
testplot <- function(m,ylab){
 d=tests[tests$metric==m,];d$comparison=factor(d$comparison,levels=rev(unique(d$comparison)))
 ggplot(d,aes(estimate,comparison,color=experimental))+
  geom_vline(xintercept=0,linetype='dashed',color='#7B8A95',linewidth=.45)+
  geom_errorbar(aes(xmin=lo,xmax=hi),orientation='y',width=.15,linewidth=.9)+
  geom_point(size=3.5)+scale_color_manual(values=colors)+labs(x=ylab,y=NULL)+
  theme(panel.grid.major.y=element_blank(),panel.grid.major.x=element_line(color='#E8ECEF',linewidth=.3),
        axis.text.y=element_text(size=15),axis.title.x=element_text(size=15))
}
savefig(testplot('heading','Difference in heading change (deg)')+
        testplot('rot','Difference in rotational-speed change (deg/s)'), 'control_contrasts',11.6,4.7)

# Baseline-state selection uses the existing 3 mm/s movement cutoff.
st=read.csv('derived/baseline_state_estimates.csv');st=factorize(st)
st$selection=factor(st$selection,levels=c('All pulses','Pre speed >= 3 mm/s'))
p=ggplot(st,aes(selection,mean,group=genotype,color=genotype))+
 geom_hline(yintercept=0,linetype='dashed',color='#7B8A95',linewidth=.4)+
 geom_line(linewidth=.85)+geom_errorbar(aes(ymin=lo,ymax=hi),width=.07,linewidth=.65)+geom_point(size=3)+
 facet_wrap(~genotype,nrow=1,labeller=as_labeller(short))+
 scale_color_manual(values=colors)+labs(x=NULL,y='Change in forward velocity (mm/s)')+
 scale_x_discrete(labels=c('All pulses','Pre speed\n>= 3 mm/s'))+
 theme(strip.background=element_blank(),strip.text=element_text(size=14,face='bold'),axis.text.x=element_text(size=11))
savefig(p,'baseline_state')

p=ggplot(fly,aes(delta_fwd,delta_heading,color=genotype))+
 geom_hline(yintercept=0,linetype='dashed',color='#A7B1BA',linewidth=.4)+
 geom_vline(xintercept=0,linetype='dashed',color='#A7B1BA',linewidth=.4)+
 geom_point(size=3,alpha=.82)+scale_color_manual(values=colors,labels=long)+
 labs(x='Change in forward velocity (mm/s)',y='Change in absolute net heading (deg)',color=NULL)+
 theme(legend.position='right',legend.text=element_text(size=14),panel.grid.major.x=element_line(color='#E8ECEF',linewidth=.3))
savefig(p,'joint_response')

# Pivot probabilities retain all fly observations, including zero rates.
piv=fly %>% select(Fly,genotype,pivot_pre,pivot_opto) %>% pivot_longer(c(pivot_pre,pivot_opto),names_to='condition',values_to='value')
piv$condition=factor(piv$condition,levels=c('pivot_pre','pivot_opto'),labels=c('Before','During'))
p=ggplot(piv,aes(condition,value,group=Fly,color=genotype))+
 geom_line(alpha=.3,linewidth=.45)+geom_point(alpha=.7,size=1.8)+
 stat_summary(aes(group=genotype),fun=mean,geom='line',linewidth=1.5)+
 stat_summary(aes(group=genotype),fun=mean,geom='point',shape=23,fill='white',color='#182B3A',size=3)+
 facet_wrap(~genotype,nrow=1,labeller=as_labeller(short))+
 scale_color_manual(values=colors)+labs(x=NULL,y='Pivot-like events (%)')+
 theme(strip.background=element_blank(),strip.text=element_text(size=14,face='bold'),axis.text.x=element_text(size=13))
savefig(p,'pivot_rates')

th=read.csv('derived/threshold_sensitivity.csv')
p=ggplot(th,aes(factor(displacement),factor(turn)))+
 geom_tile(aes(fill=estimate),color='white',linewidth=2)+
 geom_text(aes(label=sprintf('%+.2f pp',estimate)),size=6.3,family='Arial',color='#182B3A')+
 scale_fill_gradient(low='#EEF3F5',high='#C89069',limits=c(0,max(th$estimate)))+
 labs(x='Maximum net displacement (mm)',y='Minimum absolute net turn (deg)')+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),panel.grid=element_blank(),legend.position='none',axis.text=element_text(size=17))
savefig(p,'threshold_sensitivity',7.8,4.8)

tr=read.csv('derived/pulse_trends.csv');tr=factorize(tr);tr=subset(tr,metric=='heading')
p=ggplot(tr,aes(bin,mean,color=genotype,fill=genotype))+
 geom_ribbon(aes(ymin=lo,ymax=hi),alpha=.10,color=NA)+geom_line(linewidth=.95)+geom_point(size=2)+
 geom_hline(yintercept=0,color='#7B8A95',linewidth=.4,linetype='dashed')+
 scale_color_manual(values=colors,labels=long)+scale_fill_manual(values=colors,labels=long)+
 scale_x_continuous(breaks=1:8,labels=c('1-10','11-20','21-30','31-40','41-50','51-60','61-70','71-80'))+
 labs(x='Stimulation number',y='Change in absolute net heading (deg)',color=NULL,fill=NULL)+
 theme(legend.position='right',legend.text=element_text(size=14),axis.text.x=element_text(size=13))
savefig(p,'pulse_order')

# Paired first/second 500 ms comparison is not available in the local export;
# no onset time course, latency, or invented single-trial trace is generated.
writeLines(capture.output(sessionInfo()),'R_session_info.txt')
cat('Saved',length(list.files('figures',pattern='png$')),'scientific figures as PNG and SVG.\n')
