VES041 csChrimson activation: reproducible analysis and plots
13 October 2026

This package reproduces the quantitative plots in the presentation from
local exported data. It does not require the Neurobio server.

Run
  python3 analyze_ves041.py
  Rscript replot_ves041.R

Python requires numpy and pandas. R requires ggplot2, dplyr, tidyr,
jsonlite, patchwork, svglite and ragg. Arial was used for figure text.
R_session_info.txt records the plotting environment used for this deck.

On the original machine the Python executable used was:
/Users/sophiarenauld/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
R was /usr/local/bin/Rscript (R 4.4.1).

Files
  source_data/ holds exact copies of the local numeric source exports and
  relevant upstream scripts. presentation_metrics.csv and other source
  exports also contain SMP544 records. The script explicitly selects only
  dataset == ves041_activation. It never adds those records to VES041.

  derived/ holds fly-level estimates, per-pulse-bin aggregates, exploratory
  comparison statistics, threshold sensitivity and deck_data.json.

  figures/ holds 14 scientific figures in PNG and vector SVG formats.
  Open the SVG files in a vector editor, or edit the R code to replot.

  heading_relative_signed sets each pulse's initial heading to 0 degrees.
  Each fly has two dots: its zero reference and its mean signed endpoint
  shift across 80 pulses. The endpoint is the last sample in the first 1 s
  of light relative to the first sample at onset (about 0.999 s apart at
  the saved sample rate). Before = 0 is a coordinate definition, not a
  measured absence of baseline movement. The source extractor unwraps
  heading before computing the endpoint shift. No pre-window turn is
  subtracted. Source signs are retained without assuming a left/right
  anatomical convention. Opposite turns can cancel in the signed mean.

  heading_relative_absolute is the figure used on slide 6. It reflects
  each negative pulse endpoint above the horizontal 0-degree axis, then
  averages those absolute endpoint shifts within each fly. Thus After is
  mean(abs(endpoint - onset)), not abs(mean(endpoint - onset)). It measures
  displacement magnitude and prevents cancellation between pulses with
  opposite turn directions. The signed figure is retained for reference.
  Both
  figures have exactly two points per fly. Fixed horizontal offsets follow
  Fly ID within genotype and match across endpoints. Vertical values are
  unchanged. Neither figure adds group-mean markers or significance tests.

  derived/heading_pairs81.csv contains 81 paired records with signed and
  absolute endpoint values. heading_pairs_long81.csv contains 162 plotted
  points and labels the zero references with reference_only=True.
  heading_paired_summary81.csv contains descriptive group means.

  source_registry.json records original locations and original-file hashes.
  deck_data.json also records the input snapshot hashes, methods and seed.

Data conventions
  The archived summary has 84 unique flies. The pulse-derived dataset has
  81 unique flies, each with 80 stimuli (6,480 events). These are overlapping
  datasets, not independent replications. Missing pulse-analysis IDs are
  1, 6 and 39. IDs 1 and 6 are absent from the archived extraction lists.
  ID 39 appears in the recording manifest but has no extracted metrics.
  The specific extraction failure for ID 39 is not independently verified.

  The main event analysis compares the first second of light with the
  preceding second. Each fly has equal weight. No synthetic observations,
  imputation or outlier removal are used. Horizontal point jitter only
  improves visibility; vertical numeric values do not change.

  Rotational speed in the pulse export uses smoothedangularVelocity. The
  archived summary pipeline uses raw velocity fields and contains a
  moving-only summary path. The 84-fly CSV does not retain per-pulse
  inclusion metadata, so it is shown separately from all-pulse estimates.

  The baseline-state sensitivity uses pre-stimulation mean forward speed
  >= 3 mm/s, matching minVel=3 in master_behavior_analysis.m. It retains
  2,140 pulses and all 81 flies. This is descriptive and can be affected by
  conditioning on baseline. Control groups remain necessary.

  The legacy acceleration columns are preserved in their original source
  units. Their physical scaling is unresolved, so they are not used for
  the biological interpretation.

Statistics
  Seed: 20261013. Bootstrap: 20,000 resamples of flies. Intervals are
  pointwise 95% percentile intervals, not simultaneous confidence bands.

  Twelve new exploratory contrasts compare the change in each activation
  line with its matched GFP and empty-split controls for forward velocity,
  rotational speed and absolute net heading. Each comparison uses 100,000
  random-label permutations and a plus-one p-value correction. BH FDR is
  applied across all 12 comparisons. These tests are retrospective, not
  preregistered. Exact results are in exploratory_tests81.csv.

  The pooled pivot p-value on slide 13 comes from the previously saved
  ves041_activation_tests.csv. It belongs to that analysis's six-metric
  correction family, separately from the twelve new contrasts. The new
  code reproduces the underlying pivot rates and all nine saved threshold
  sensitivity values from the event table.

  Strict pivot rule: absolute net heading >=45 deg, net displacement <=2mm,
  directionality >=0.7. Directionality is absolute net heading / cumulative
  absolute heading change. The same rule applies before and during light.

Presentation assets
  Original example path figures come from labmeeting_9.pptx slide 22.
  image32 is the source-labeled VES041 example and image31 the empty-split
  control. Their arbitrary-unit axes are retained. These examples are
  illustrative and do not establish the 2mm pivot cutoff.

  The fly-on-ball schematic comes from slide 18 of that deck. Only
  surrounding transparent whitespace is cropped within the slide layout.

  PowerPoint text, tables and the pivot overview chart remain editable.
  Detailed scientific plots are embedded figures with these SVG/code
  counterparts. Pivot-chart workbook values are rounded to eight decimal
  places for Excel compatibility. Unrounded estimates remain in the CSVs.

Scope
  This reproduction begins with saved local numeric exports. It does not
  rerun raw acquisition processing, reconstruct unseen raw traces, infer
  response onset latency, or establish a downstream circuit mechanism.
  Earlier pilot and inhibition data are not pooled into this cohort.
